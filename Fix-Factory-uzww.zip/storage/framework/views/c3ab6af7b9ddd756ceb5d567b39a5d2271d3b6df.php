<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($name); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php if($is_admin): ?>
<h1>Profile</h1>
<?php endif; ?>
<?php /**PATH /home/saami/Desktop/Projects/Laravel-Basic/src/resources/views/videos.blade.php ENDPATH**/ ?>